#Get function from api folder files.
$API  = @( Get-ChildItem -Path api\*.ps1 -ErrorAction SilentlyContinue )

#Dot source the files
Foreach($import in @($API))
{
    Try
    {
        . $import.fullname
    }
    Catch
    {
        Write-Error -Message "Failed to import function $($import.fullname): $_"
    }
}

# stop program on eny error
$ErrorActionPreference = "Stop"

$currentDate = Get-Date
# format - currentMonth-currentDay with leading zeros
$postfix = $currentDate.ToString("MM.dd")
$newBranchName = "release-$postfix"
Write-Host "creating branch $newBranchName...."
# create policy settings to the new branch
$createBranchResult = Create-New-Branch-From-Source-Branch -SourceBranchName master -NewBranchName $newBranchName
Write-Host "branch $newBranchName created from master"
$setPolicySettingResult1 = Set-Required-Reviewer-Count-Policy-Setting -RefName $newBranchName -MinReviewerCount 1
Write-Host "Policy setting of minimum count of reviewers created"
$setPolicySettingResult1 = Set-Merge-Strategy-Policy-Setting -RefName $newBranchName -AllowSquash $true
Write-Host "Policy setting of merge rules created"

# get necessary definitions
$necessaryBuildDefinitionNames = new-object string[] 3 
$necessaryBuildDefinitionNames[0] = "[P][Master][CI]"
$necessaryBuildDefinitionNames[1] = "[P][Master][PR]"
$necessaryBuildDefinitionNames[2] = "[P][Master][Validation]"

$definitions = Get-Necessary-Definitions -NecessaryBuildDenifitionNames $necessaryBuildDefinitionNames
foreach ($definition in $definitions) {
    $definition.name = $definition.name -replace "\[Master\]", "[Master][$postfix]"
    Write-Host "Creating definition $($definition.name)"
    # change values of some properties to its default value
    $definition.revision = 1
    $definition._links = $null
    $definition.url = $null 
    $definition.id = -1
    $createdDefinition = Create-Definition -Data $definition
    Write-Host "Definition $($definition.name) created"
    $setPolicySettingResult = Set-Build-Validation-Policy-Settings -RefName $newBranchName -BuildDefinitionId $createdDefinition.id
    Write-Host "Policy of build validation for branch $newBranchName related to $($definition.name) created"
}

Write-Host "Success!"  
